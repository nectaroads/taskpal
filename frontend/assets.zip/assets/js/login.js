import { sendRequest, showLoadingOverlay, hideLoadingOverlay, showNotification, autoLogin } from './script.js';

let disabled = true;
let loading = false;
let inputUsername = '';
let inputPassword = '';

const loginInput = document.getElementById('input_username');
const passwordInput = document.getElementById('input_password');
const loginBtn = document.getElementById('button_login');

loginInput.value = '';
passwordInput.value = '';

function validateUser() {
  let validate = true;
  if (inputUsername.length < 5) validate = false;
  if (inputPassword.length < 8) validate = false;
  if (validate) {
    loginBtn.classList.remove('disabled');
    disabled = false;
  } else {
    loginBtn.classList.add('disabled');
    disabled = true;
  }
}

if (loginInput) {
  loginInput.addEventListener('input', event => {
    inputUsername = event.target.value;
  });
  loginInput.addEventListener('change', event => {
    validateUser();
    if (inputUsername == '') return;
    if (inputUsername.length < 5) {
      inputUsername = '';
      event.target.value = '';
      return showNotification('O seu usuário é curto demais! Precisa ter ao menos 5 caracteres');
    }
  });
}

if (passwordInput) {
  passwordInput.addEventListener('input', event => {
    inputPassword = event.target.value;
  });
  passwordInput.addEventListener('change', event => {
    validateUser();
    if (inputPassword == '') return;
    if (inputPassword.length < 8) {
      inputPassword = '';
      event.target.value = '';
      return showNotification('A sua senha é curta demais! Precisa ter ao menos 8 caracteres');
    }
  });
}

if (loginBtn) {
  loginBtn.addEventListener('click', async event => {
    if (loading || disabled) return;
    loading = true;
    showLoadingOverlay();
    try {
      const json = { key: 'login', value: { username: inputUsername, password: inputPassword } };
      await sendRequest(json);
    } finally {
      loading = false;
      hideLoadingOverlay();
    }
  });
}

autoLogin();