import { print } from './io.js';

const server = 'http://192.168.0.121:24575/taskpal';
const delay = 3;

export let token = localStorage.getItem('taskpal_token') || localStorage.getItem('taskpal_intance') || null;

const logoutHandler = {
  success: value => {
    token = null;
    localStorage.removeItem('taskpal_token');
    localStorage.removeItem('taskpal_intance');
    window.location.href = 'index.html';
  }
};

const loginHandler = {
  success: value => {
    token = value.token;
    localStorage.setItem('taskpal_token', token);
    window.location.href = 'home.html';
  },
  invalidUsername: value => {
    showNotification('Essa conta não existe');
  },
  invalidPassword: value => {
    showNotification('Essa senha está incorreta');
  }
};

const responseHandler = {
  login: value => {
    print(`[Request] Request type: ${value.type}`);
    if (loginHandler[value.type]) loginHandler[value.type](value);
  },
  logout: value => {
    print(`[Request] Request type: ${value.type}`);
    if (logoutHandler[value.type]) logoutHandler[value.type](value);
  }
};

export async function autoLogin() {
  if (token) {
    showLoadingOverlay();
    try {
      const json = { key: 'token', value: { token: token } };
      await sendRequest(json);
    } finally {
      hideLoadingOverlay();
    }
  }
}

export async function sendRequest(json) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      $.ajax({
        url: server,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(json),
        success: function (res) {
          if (res) {
            print(`[Request] Request response: ${res.key}`);
            if (responseHandler[res.key]) {
              responseHandler[res.key](res.value);
            }
            resolve(res);
          } else {
            resolve(null);
          }
        },
        error: function (xhr, status, err) {
          let res = null;
          if (xhr && xhr.responseText) res = JSON.parse(xhr.responseText);
          if (res) {
            print(`[Request] Request response: ${res.key}`);
            if (responseHandler[res.key]) {
              responseHandler[res.key](res.value);
            }
            resolve(null);
          } else {
            reject(err);
          }
        }
      });
    }, 1000 * delay);
  });
}

export function showLoadingOverlay() {
  let overlay = document.createElement('div');
  overlay.id = 'loading-overlay';
  overlay.innerHTML = `<div class="spinner"></div>`;
  document.body.appendChild(overlay);
}

export function hideLoadingOverlay() {
  const overlay = document.getElementById('loading-overlay');
  if (overlay) overlay.remove();
}

export function showNotification(message) {
  const existing = document.getElementById('notification-overlay');
  if (existing) existing.remove();
  const overlay = document.createElement('div');
  overlay.id = 'notification-overlay';
  overlay.innerHTML = `<div class="notification-bubble"><span>${message}</span></div>`;
  overlay.addEventListener('click', () => overlay.remove());
  document.body.appendChild(overlay);
}
