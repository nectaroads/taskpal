import { hideLoadingOverlay, sendRequest, showLoadingOverlay, token } from './script';

let loading = false;

const logoutBtn = document.getElementById('button_logout');

if (logoutBtn) {
  console.log('button found');
  logoutBtn.addEventListener('click', async event => {
    console.log('button click');
    if (loading) return;
    loading = true;
    showLoadingOverlay();
    try {
      const json = { key: 'logout', value: { token: token } };
      await sendRequest(json);
    } finally {
      loading = false;
      hideLoadingOverlay();
    }
  });
}
